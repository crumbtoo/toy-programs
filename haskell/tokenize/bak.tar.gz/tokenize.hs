module Tokenize (tokenize) where

trimStart :: String -> String
trimStart whole@(s:st) = if s == ' '
                         then trimStart st
                         else whole

trimEnd :: String -> String
trimEnd s = (reverse.trimStart.reverse) s

trim :: String -> String
trim s = (trimStart.trimEnd) s

firstWord' :: String -> String
firstWord' [c] = [c]
firstWord' (s:st) = if s == ' '
                    then ""
                    else [s] ++ (firstWord' st)

firstWord :: String -> String
firstWord s = (firstWord'.trimStart) s

notFirstWord' :: String -> String
notFirstWord' "" = ""
notFirstWord' (s:st) = if s == ' '
                       then trim st
                       else notFirstWord' st

notFirstWord :: String -> String
notFirstWord = (notFirstWord'.trim)


tokenize :: String -> [String]
tokenize "" = []
tokenize s = [firstWord s] ++ tokenize (notFirstWord s)


main = do
    s <- getLine
    print(tokenize s)
